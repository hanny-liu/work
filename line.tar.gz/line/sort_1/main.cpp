#include <iostream>
#include <opencv4/opencv2/calib3d.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/calib3d.hpp>
#include <opencv2/imgcodecs.hpp>
#include <vector>
using namespace std;
using namespace cv;
//针对正常情况的标志位
const int NORMAL = 0;
//针对非正常情况的标志位
const int ABNORMAL = 1;
//针对不考虑情况的标志位
const int WTF = -1;
//代表移动瓷砖
const int MOVE = 1;
//代表静止瓷砖
const int STATIC = 0;
//高斯模糊的滤波器大小
const int KERNEL = 5;
//高斯滤波x方向方差
const double SIGMAX = 3.0;
//高斯滤波y方向方差
const double SIGMAY = 3.0;
//边缘检测canny用的低阈值
const int LOW_THRESHOLD = 80;
///const int LOW_THRESHOLD = 100;
//边缘检测canny用的高阈值
const int HIGH_THRESHOLD = 200;
//轮廓滤波时的阈值,面积小于此数值的轮廓会被过滤掉
const double THRESHOLD = 100.0;
//霍夫变换时的阈值
///const int H_THRESHOLD = 50;
const int H_THRESHOLD = 100;
//画线时线的粗细度
const int THICKNESS = 1;
//画线的通道连接
const int LINETYPE = 8;
//画圆时圆的半径
const int RADIUS = 8;
//霍夫变换距离解析度
const double HOUGH_RHO = 1;
//霍夫变换角度解析度
const double HOUGH_THETA = CV_PI / 180;
//定义离静止瓷砖角点的距离
const int distance = 50;
//定义离静止pylon获取图像时最大缓存
const int MAX_BUFFER = 5;
//定义经过去畸变后的图像的宽
const int WIDTH = 757;
//定义经过去畸变后图像的高
const int HEIGHT = 537;
//定义一共抓取多少张图片;
const uint32_t C_COUNTOFIMAES = 10;

Point sliding_windows(Mat im, const Point3d & s)//判断每个vector是否有
{
    auto current=s;
    current.z=1;
    vector<Point3d> p;
    copyMakeBorder(im, im,1, 1, 1, 1,BORDER_CONSTANT);//扩充图片边界
    //遍历每个点的3*3矩阵
    int n(1);
    while(1)
    {
        for(int i=-1;i<2;i++) {
            for (int j = -1; j < 2; j++) {
                if (i == 0 && j == 0)
                    continue;
                p.emplace_back(Point3d(current.x + i, current.y + j, 0));
            }
        }
        for(auto i:p)
        {
            if(im.at<uchar>(i.y,i.x)==255&&i.z!=1)
            {
                current=i;
                current.z=1;
                break;
            }
            /***else if(i.x==0||i.x==im.cols||i.y==0||i.y==im.rows)
            {
                continue;
            } ***/
            else if(im.at<uchar>(i.y,i.x)!=255)
            {
                continue;
            } else
            {
                cout<<"断点在："<<current.x<<","<<current.y<<endl;
                return Point(current.x,current.y);
            }
        }
        p.clear();
        n++;
    }
    return Point(-1,-1);
}
template <typename T>
float distancepoint(const T & p1,const T & p2)
{
    float x_=p1.x-p2.x;
    float y_=p1.y-p2.y;
    float d=pow((x_*x_+y_*y_),0.5);
    return d;
}

Point search(Mat image,const Point & p)
{
    int flag=0;
    Point ij(-2,-2);
    for(int i=-1;i<2;i++)
    {
        for(int j=-1;j<2;j++)
        {
            if(i==0&&j==0)
                continue;
            else if(p.x>image.cols||p.y>image.rows||p.x<0||p.y<0)
                break;
            else if(image.at<uchar>(p.y+j,p.x+i)==255)
            {
                ij.x=i;
                ij.y=j;
                return ij;
            }
        }
    }
    return ij;
}

Point search1(Mat image,const Point & p,const Point & p1)
{
    int flag=0;
    Point ij(-2,-2);
    for(int i=-1;i<2;i++)
    {
        for(int j=-1;j<2;j++)
        {
            if((i==0&&j==0)||(i==p1.x&&j==p1.y))
                continue;
            else if(p.x>image.cols||p.y>image.rows||p.x<0||p.y<0)
                break;
            else if(image.at<uchar>(p.y+j,p.x+i)==255)
            {
                ij.x=i;
                ij.y=j;
                return ij;
            }
        }
    }
    return ij;
}

vector<Point> complete(Mat &edges,vector<Point3d> &couner) {
    //Point ij1, ij2;
    vector<Point> ij;
    copyMakeBorder(edges, edges, 1, 1, 1, 1, BORDER_CONSTANT);//扩充图片边界
    for (int i = 0; i < couner.size(); i+=2) {
        for (int j = couner.size() /2; j > i/2; j--) {
            float d1=distancepoint(couner[i],couner[j*2]);
            float d2=distancepoint(couner[i],couner[j*2+1]);
            float d3=distancepoint(couner[i+1],couner[j*2]);
            float d4=distancepoint(couner[i+1],couner[j*2+1]);
            if(d1<=20&&couner[i]!=couner[j*2]&&couner[i].z!=couner[j*2].z)
            {
                ij.emplace_back(i/2,j*2);
            }
            if(d2<=20&&couner[i]!=couner[j*2+1]&&couner[i].z!=couner[j*2+1].z)
            {
                ij.emplace_back(i/2,j*2+1);
            }
            if(d3<=20&&couner[i+1]!=couner[j*2]&&couner[i+1].z!=couner[j*2].z)
            {
                ij.emplace_back(i/2,j*2);
            }
            if(d4<=20&&couner[i+1]!=couner[j*2+1]&&couner[i+1].z!=couner[j*2+1].z)
            {
                ij.emplace_back(i/2,j*2+1);
            }
            //if (distancepoint(couner[i], couner[j]) <= 50&&couner[i]!=couner[j]&&couner[i].z!=couner[j].z)///条件需要考量
            //{
               // ij.emplace_back(i,j);
                /***
                int t1 = couner[i].x - couner[j].x;
                int t2 = couner[i].y - couner[j].y;
                ij1 = search(edges, couner[i]);
                ij2 = search(edges, couner[j]);
                Point ci = couner[i];
                Point cj = couner[j];
                if (abs(t1) == abs(t2)) {
                    for (int i = 0; i < abs(t1); i++)///需要考虑t1和t2的符号
                    {
                        edges.at<uchar>(ci.y - ij1.y * i, ci.x - ij1.x * i) = 255;
                        edges.at<uchar>(cj.y - ij2.y * i, cj.x - ij2.x * i) = 255;
                    }

                } else if (couner[i].x == couner[j].x || couner[i].y == couner[j].y) {
                    if (t1 != 0)///需要考虑t1和t2的符号
                    {
                        for (int i = 0; i < abs(t1); i++)
                        {
                            edges.at<uchar>(ci.y - ij1.y, ci.x - ij1.x) = 255;
                            edges.at<uchar>(cj.y - ij2.y, cj.x - ij2.x) = 255;
                        }
                    } else {
                        for (int i = 0; i < abs(t2); i++)///需要考虑t1和t2的符号
                        {
                            edges.at<uchar>(ci.y - ij1.y, ci.x - ij1.x) = 255;
                            edges.at<uchar>(cj.y - ij2.y, cj.x - ij2.x) = 255;
                        }
                    }

                } else {
                    float k1=ij1.y/ij1.x;
                    float b1=couner[i].y-couner[i].x*k1;
                    float k2=ij2.y/ij2.x;
                    float b2=couner[j].y-couner[j].x*k2;
                    float x3 = (b2-b1)/(k2-k1);
                    float y3=k1*x3+b1;
                    float x1 = couner[i].x;
                    float y1 = couner[i].y;
                    float x2 = couner[j].x;
                    float y2 = couner[j].y;
                    float x_13=abs(x1-x3);
                    float y_13=abs(y1-y3);
                    float x_23=abs(x2-x3);
                    float y_23=abs(y2-y3);
                    if(x_13<=y_13)
                    {
                        for (int i = 0; i < x_13; i++)
                        {
                            edges.at<uchar>(y1 - ij1.y * i, x1 - ij1.x * i) = 255;
                        }
                    } else
                    {
                        for (int i = 0; i < y_13; i++)
                        {
                            edges.at<uchar>(y1 - ij1.y * i, x1 - ij1.x * i) = 255;
                        }
                    }
                    if(x_23<=y_23)
                    {
                        for (int i = 0; i < x_23; i++)
                        {
                            edges.at<uchar>(y2 - ij2.y * i, x2 - ij2.x * i) = 255;
                        }
                    } else
                    {
                        for (int i = 0; i < y_23; i++)
                        {
                            edges.at<uchar>(y2 - ij2.y * i, x2 - ij2.x * i) = 255;
                        }
                    }
                    ***/
                    /**
                    float c = distancepoint(couner[i], couner[j]);
                    int x3 = couner[j].x;
                    int y3 = couner[i].y - x3 + couner[i].x;
                    float xi = couner[i].x;
                    float yi = couner[i].y;
                    float xj = couner[j].x;
                    float yj = couner[j].y;
                    float a = abs(-x3 + couner[i].x);
                    Point E(couner[i].x - ij1.x * a / 2.0, couner[i].y - ij1.y * a / 2.0);//缺失角点
                    edges.at<uchar>(couner[i].y - ij1.y * a / 2.0, couner[i].x - ij1.x * a / 2.0) = 255;

                    for (int i = 0; i < abs(ij1.x * a / 2.0); i++)
                    {
                        edges.at<uchar>(yi - ij1.y * i, xi - ij1.x * i) = 255;
                    }
                    float t1 = couner[i].x - ij1.x * a / 2.0 - xj;
                    for (int i = 0; i < abs(t1); i++)
                    {
                        edges.at<uchar>(yj + ij2.y * i, xj + ij2.x * i) = 255;
                    }**/
            //}

            }
        }
    return ij;
    }

vector<Point2d> compute_k_center(vector<vector<Point2d>> & k_means)
{
    vector<Point2d> k_center1;
    k_center1.resize(k_means.size());
    float av_x(0), av_y(0);
    for (int i = 0; i < k_means.size(); i++) {
        for (auto j:k_means[i]) {
            av_x += j.x;
            av_y += j.y;
        }
        k_center1[i].x = av_x / k_means[i].size();
        k_center1[i].y = av_y / k_means[i].size();
    }
    return k_center1;
}

vector<Point2d> initial_k_means(Mat image,vector<Point2d> & point)
{
    vector<Point2d> center1;
    vector<Point2d> center2;
    int lt_x = image.cols / 4;
    int lt_y = image.rows / 4;
    int tm_x = image.cols / 2;
    int tm_y = image.rows / 4;
    int ltm_x = image.cols / 4;
    int ltm_y = image.rows / 2;
    int rtm_x = image.cols / 2+image.cols / 4;
    int rtm_y = image.rows / 2;
    int bm_x = image.cols / 2;
    int bm_y = image.rows / 4+image.rows/2;
    int rt_x = lt_x + image.cols / 2;
    int rt_y = lt_y;
    int lb_x = lt_x;
    int lb_y = lt_y + image.rows / 2;
    int rb_x = rt_x;
    int rb_y = lb_y;
    center1.emplace_back(Point2d(lt_x,lt_y));
    center1.emplace_back(Point2d(rt_x,rt_y));
    center1.emplace_back(Point2d(lb_x,lb_y));
    center1.emplace_back(Point2d(rb_x,rb_y));
    center1.emplace_back(Point2d(tm_x,tm_y));
    center1.emplace_back(Point2d(ltm_x,ltm_y));
    center1.emplace_back(Point2d(rtm_x,rtm_y));
    center1.emplace_back(Point2d(bm_x,bm_y));
    /***int flage=0;
    for(int i=0;i<center1.size();i++)
    {
        for(int m=-1;m<2;m++)
        {
            for(int n=-1;n<2;n++)
            {
                if(image.at<uchar>(center1[i+m].x,center1[i+n].y)==0)
                    flage=1;
            }
            if(flage==1)
                break;
        }
        if(flage==1)
            break;
    }**/
    vector<float> distance;
    int f;
    vector<vector<Point2d>> C;
    C.resize(8);
    map<int,int> final_center;
   //if (flage==1)

       float min (0);
       for (int i = 0; i < point.size(); i++)//遍历所有point
       {
           for (int j = 0; j < 8; j++)//计算每个点都k个中心点的距离
           {
               float d =distancepoint(point[i],center1[j]);
               distance.push_back(d);
               /**for(int i=0;i<good_contours.size();i++)
               {
                   for(int j=0;j<good_contours[i].size();j++)
                   {
                       couner.push_back(good_contours[i][j]);
                       //cout<<*good_contours[i].begin()<<endl;
                     circle(image,k_mean[0][i], 50, Scalar(0,0,0));   //circle(image,*good_contours[i].begin(), 50, Scalar(0,0,0));
                       circle(image,good_contours[i][j], 5, Scalar(0,0,0));
                   }
               }**/
           }
           min=distance[0];
           for (int m = 1; m < 8; m++)//找出每个点最小距离的点
           {
               if (min > distance[m])
               {
                   min = distance[m];
                   f = m;
               }
           }
           //重新归类
           C[f].push_back(point[i]);//将每个点最短距离所属的中心归为一类
           distance.clear();
           min=0;
           f=0;
       }
       auto max=C[0].size();
       //Point2d min_p;
       //auto iterator=center2.end();
       int o(0);
       //int r=0;
       for(int j=0;j<4;j++)
       {
           for(int i=1;i<4;i++)
           {
               if(max<C[i].size())
               {
                   max=C[i].size();
                   o=i;
               }
           }
           auto temp=center1[j];
           center1[j]=center1[o];
           center1[o]=temp;
       }
       return center1;
   /***else
   {
       float min = distance[0];
       for (int i = 0; i < point.size(); i++)//遍历所有point
       { for (int j = 0; j < 4; j++)//计算每个点都k个中心点的距离
           {
               float d =distancepoint(point[i],center1[j]);
               distance.push_back(d);
               /**for(int i=0;i<good_contours.size();i++)
               {
                   for(int j=0;j<good_contours[i].size();j++)
                   {
                       couner.push_back(good_contours[i][j]);
                       //cout<<*good_contours[i].begin()<<endl;
                     circle(image,k_mean[0][i], 50, Scalar(0,0,0));   //circle(image,*good_contours[i].begin(), 50, Scalar(0,0,0));
                       circle(image,good_contours[i][j], 5, Scalar(0,0,0));
                   }
               }**/
           //}
      /***     min=distance[0];
           for (int m = 1; m < 4; m++)//找出每个点最小距离的点
           {
               if (min > distance[m])
               {
                   min = distance[m];
                   f = m;
               }
           }
           //重新归类
           C[f].push_back(point[i]);//将每个点最短距离所属的中心归为一类
           distance.clear();
       }
       auto max=C[0].size();
       //Point2d min_p;
       //auto iterator=center2.end();
       int o(0);
       //int r=0;
       for(int j=0;j<4;j++)
       {
           for(int i=1;i<4;i++)
           {
               if(max<C[i].size())
               {
                   max=C[i].size();
                   o=i;
               }
           }
           auto temp=center1[j];
           center1[j]=center1[o];
           center1[o]=temp;
       }
       return center2;***/

}

vector<vector<Point2d>> k_means(Mat & image, vector<vector<cv::Point>> & good_contours, vector<Vec4f> & plines)
{
    int k = good_contours.size();
    int max = good_contours[0].size();
    float t = 0.9;
    int count(0);
    if (k % 2 == 1) {
        for (int i = 1; i < good_contours.size(); i++) {
            if (max < good_contours[i].size())
                max = good_contours[i].size();
        }
        for (int i = 0; i < good_contours.size(); i++) {
            if (max * t > good_contours[i].size())
                count++;
        }
        k -= count / 2;
    }
    vector<int> seq;//读入point点
    vector<Point2d> k_center;
    int n=0;
    vector<Point2d> point;
    vector<Point2d> point0;
    for(int i=0;i<plines.size();i++)
    {
        point.emplace_back(Point2d(plines[i][0],plines[i][1]));
        point.emplace_back(Point2d(plines[i][2],plines[i][3]));
    }
    point0=point;
    for (int i = 0; i < image.cols; i+=100)
        {
            point0.emplace_back(i, 0);
            point0.emplace_back(i, image.rows);
        }
        for (int j = 0; j < image.rows; j+=100)
        {
            point0.emplace_back(0, j);
            point0.emplace_back(image.cols, j);
        }
    /***for (int i = 1; i <= k; i++)
    {
        Point2d p(0,0);
        for(int j=0;j<point.size();j++)
        {
            {
                p+=point[j];
                n++;
            }
            if(i<k&&n==i*(point.size()/(2*k)))
            {
                k_center.emplace_back((p/(2*k)));
                p=Point2d(0,0);
            }
            else if(i==k&&n==plines.size()-1)
            {
                k_center.emplace_back((p/(n-i*2*k)));
            }
        }
    }***/
    k_center=initial_k_means(image,point0);
    auto iterator=k_center.begin();
    if(k<k_center.size())
    {
        for(int i=k_center.size()-1;i>k-1;i--)
        {
            k_center.erase(iterator+i);
        }
    }
    for(auto i:k_center)
        circle(image,i, 50, Scalar(255));
    imshow("feature", image);
    waitKey(0);
    //3对每一个样本,计算与每个中心点之间的距离,取最小的作为它的归类;
    vector<Point2d> k_center1;
    k_center1.resize(k);
    int con(1);//循环计数
    vector<vector<Point2d>> k_means;//各个中心点包含的二维点数
    k_means.resize(k);
    vector<float> distance;//每次每个点的到k个中心点的距离
    vector<vector<Point2d>> k_means_update;//各个中心点包含的二维点数
    //开始循环迭代
    int q=1;
    while (q<1000) {
        float flag(0);
        k_means.resize(k);
        for (int i = 0; i < point.size(); i++)//遍历所有point
        { for (int j = 0; j < k; j++)//计算每个点都k个中心点的距离
            {
                float d =distancepoint(point[i],k_center[j]);
                distance.push_back(d);
                /**for(int i=0;i<good_contours.size();i++)
                {
                    for(int j=0;j<good_contours[i].size();j++)
                    {
                        couner.push_back(good_contours[i][j]);
                        //cout<<*good_contours[i].begin()<<endl;
                      circle(image,k_mean[0][i], 50, Scalar(0,0,0));   //circle(image,*good_contours[i].begin(), 50, Scalar(0,0,0));
                        circle(image,good_contours[i][j], 5, Scalar(0,0,0));
                    }
                }**/
            }
            float min = distance[0];
            flag = 0;
            for (int m = 1; m < k; m++)//找出每个点最小距离的点
            {
                if (min > distance[m])
                {
                    min = distance[m];
                    flag = m;
                }
            }
            //重新归类
            k_means[flag].push_back(point[i]);//将每个点最短距离所属的中心归为一类
            distance.clear();
        }
        //4重新计算每个类的中心点。
        k_center1=compute_k_center(k_means);
        //5如果每个中心点都变化很小,则算法收敛,退出;否则返回 1。
        for (int i = 0; i < k; i++) {
            float change = distancepoint(k_center[i],k_center1[i]);
            if (change <= 100)
            {
                flag = 0;
                break;
            } else
                flag = 1;
        }
        if (flag == 0) {
            k_means_update = k_means;
            break;
        }
        k_means_update = k_means;
        k_center = k_center1;
        k_center1.clear();
        k_means.clear();
        cout << "第" << con << "次循环" << endl;
        con++;
        q++;
    }
    return k_means;
}

vector<Vec2f> hough_extract(Mat &image0)
{
    vector<Vec2f> plines;
    vector<Vec2f> result;
    HoughLines(image0, plines,HOUGH_RHO, HOUGH_THETA, H_THRESHOLD);
    vector<vector<Point>> p1p2;
    p1p2.resize(plines.size());
    for(int i=0;i<plines.size();i++)
    {
        auto hline=plines[i];
        float rho = hline[0], theta = hline[1];
        Point pt1, pt2;
        double a = cos(theta), b = sin(theta);
        double x0 = a*rho, y0 = b*rho;
        pt1.x = cvRound(x0 + 1000*(-b));
        pt1.y = cvRound(y0 + 1000*(a));
        pt2.x = cvRound(x0 - 1000*(-b));
        pt2.y = cvRound(y0 - 1000*(a));
        p1p2[i].push_back(pt1);
        p1p2[i].push_back(pt2);
        //line( image, pt1, pt2, Scalar(0,0,255), 3);
        //line(image, Point(0, 0), Point(hline[0]*cos(hline[1]),hline[0]*sin(hline[1]) ), Scalar(0), 1, LINE_AA);
    }
    //imshow("feature", image);
    //waitKey(0);
    float xl1(0);
    float xl2(0);
    Vec2f xl_1(0,0);
    Vec2f xl_2(0,0);
    Point p1(0,0),p2(0,0);
    int n1(0),n2(0);
    //vector<Point> fit_point1;
    //vector<Point> fit_point2;
    for(int i=0;i<=p1p2.size()-2;i+=2)
    {
        xl1=float(p1p2[i][1].y-p1p2[i][0].y)/float(p1p2[i][1].x-p1p2[i][0].x);
        xl2=float(p1p2[i+1][1].y-p1p2[i+1][0].y)/float(p1p2[i+1][1].x-p1p2[i+1][0].x);
        if(xl1*xl2<0)
        {
            if(xl1>0&&xl2<0)
            {
                xl_1+=plines[i];
                xl_2+=plines[i+1];
                //fit_point1.push_back(p1p2[i][0]);
                //fit_point1.push_back(p1p2[i][1]);
                //fit_point2.push_back(p1p2[i+1][0]);
                //fit_point2.push_back(p1p2[i+1][1]);
                n1++;
                n2++;
            }
            else
            {
                xl_1+=plines[i+1];
                xl_2+=plines[i];
                //fit_point2.push_back(p1p2[i][0]);
                //fit_point2.push_back(p1p2[i][1]);
                //fit_point1.push_back(p1p2[i+1][0]);
                //fit_point1.push_back(p1p2[i+1][1]);
                n1++;
                n2++;
            }
        } else
        {
            if(xl1>=0)
            {
                xl_1+=plines[i]+plines[i+1];
                //fit_point1.push_back(p1p2[i][0]);
                //fit_point1.push_back(p1p2[i][1]);
                //fit_point1.push_back(p1p2[i+1][0]);
                //fit_point1.push_back(p1p2[i+1][1]);
                n1+=2;
            }
            else
            {
                xl_2+=plines[i+1]+plines[i];
                //fit_point2.push_back(p1p2[i][0]);
                //fit_point2.push_back(p1p2[i][1]);
                //fit_point2.push_back(p1p2[i+1][0]);
                //fit_point2.push_back(p1p2[i+1][1]);
                n2+=2;
            }
        }
    }
    if(n1==0)
    {
        xl_2/=n2;
        plines.clear();
        plines.resize(1);
        plines[0]=Vec2f(-1,-1);
        return plines;
    }
    else if(n2==0)
    {
        xl_1/=n1;
        plines.clear();
        plines.resize(1);
        plines[0]=Vec2f(-1,-1);
        return plines;
    }
    else
    {
        xl_1/=n1;
        xl_2/=n2;
        vector<Vec2f> x;
        x.push_back(xl_1);
        x.push_back(xl_2);
        float rho1 = xl_1[0], theta1 = xl_1[1];
        float rho2 = xl_2[0], theta2 = xl_2[1];
        Point pt1, pt2,pt3,pt4;
        double a1 = cos(theta1), b1 = sin(theta1);
        double x0 = a1*rho1, y0 = b1*rho1;
        pt1.x = cvRound(x0 + 1000*(-b1));
        pt1.y = cvRound(y0 + 1000*(a1));
        pt2.x = cvRound(x0 - 1000*(-b1));
        pt2.y = cvRound(y0 - 1000*(a1));
        double a2 = cos(theta2), b2 = sin(theta2);
        double x2 = a2*rho2, y2 = b2*rho2;
        pt3.x = cvRound(x2 + 1000*(-b2));
        pt3.y = cvRound(y2 + 1000*(a2));
        pt4.x = cvRound(x2 - 1000*(-b2));
        pt4.y = cvRound(y2 - 1000*(a2));
        //circle( image,pt1, 10, Scalar(255));
        //cMatircle( image,p1, 10, Scalar(255));
        //pt2.x = cvRound(x0 - 1000*(-b));
        //pt2.y = cvRound(y0 - 1000*(a));
        ///进行直线拟合
       // Vec4f fitted_point1,fitted_point2;
       // Point x_1,x_2,x_3,x_4;
        //fitLine(fit_point1,fitted_point1,DIST_HUBER  ,0,0.01,0.01);
        //fitLine(fit_point2,fitted_point2,DIST_HUBER  ,0,0.01,0.01);
        //float k_1=fitted_point1[1]/fitted_point1[0];
        //float b_1=fitted_point1[3]-k_1*fitted_point1[2];
        //float k_2=fitted_point2[1]/fitted_point2[0];
        //float b_2=fitted_point2[3]-k_1*fitted_point2[2];

        //x_1.x=cvRound(fitted_point1[2]-500);
        //x_1.y=cvRound(k_1*x_1.x+b_1);
        //x_2.x=cvRound(fitted_point1[2]+500);
        //x_2.y=cvRound(k_1*x_2.x+b_1);

        //x_3.x=cvRound(fitted_point2[2]-500);
        //x_3.y=cvRound(k_2*x_3.x+b_2);
        //x_4.x=cvRound(fitted_point2[2]+500);
        //x_4.y=cvRound(k_2*x_4.x+b_2);

        line( image0, pt1, pt2, Scalar(255), 1);
        line( image0, pt3, pt4, Scalar(255), 1);
        cout<<"plines:"<<plines.size()<<endl;
        return x;
    }

}

vector<Point2d> compute_xy(Mat & image,float k,float b)
{
    vector<Point2d> intersection;
    float x1,x2,y1,y2,x3,y3,x4,y4;
    x1=0;
    y1=k*x1+b;
    x2=image.cols;
    y2=k*x2+b;
    y3=0;
    x3=(y3-b)/k;
    y4=image.rows;
    x4=(y4-b)/k;
    if(y1<0||y1>image.rows)
    {
        if(y2<0||y2>image.rows)
        {
            intersection.emplace_back(x3,y3);
            intersection.emplace_back(x4,y4);
        } else
        {
            intersection.emplace_back(x2,y2);
            if(x3<0||x3>image.cols)
                intersection.emplace_back(x4,y4);
            else
                intersection.emplace_back(x3,y3);
        }
    } else
    {
        intersection.emplace_back(x1,y1);
        if(y2<0||y2>image.rows)
        {
            if(x3<0||x3>image.cols)
                intersection.emplace_back(x4,y4);
            else
                intersection.emplace_back(x3,y3);
        } else
        {
            intersection.emplace_back(x2,y2);
        }
    }
    return intersection;
}

int main()
{

    cv::Mat blur;
    cv::Mat edges;
    vector<vector<cv::Point>> contours;
    vector<cv::Vec4i> hierarchy;
    vector<vector<cv::Point>> good_contours;
    cv::Mat image;
    cv::Mat median;
    double area;
    int size;
    vector<Mat> img;
    string file;
    for (int i = 1; i < 14; i++) {

        file = "/home/lhw/lhw/工作/cv_test4/" + to_string(i) + ".png";
        //file = "/home/lhw/lhw/工作/locate_first_tile/image" + to_string(i) + ".png";
        image = imread(file);
        img.push_back(image);
    }
    int quantity(0);
    //image=imread("/home/lhw/lhw/工作/cv_test1/9.jpg");
    for (int l = 12; l < img.size(); l++)
    {
        quantity++;
        cout<<"第"<<quantity<<"次"<<endl;
        //image = imread("/home/lhw/lhw/工作/cv_test1/1553230448.81_image.jpg");
        image=img[l];
        resize(image,image,Size(700,500));
        GaussianBlur(image, blur, cv::Size(KERNEL, KERNEL), SIGMAX, SIGMAY); //高斯模糊,去除小噪点,同时让图像边平滑
        medianBlur( blur, blur ,9 );
        Canny(blur, edges, LOW_THRESHOLD, HIGH_THRESHOLD);                   //边缘检测,canny算法
        findContours(edges, contours, hierarchy, RETR_EXTERNAL, CHAIN_APPROX_NONE); //在边缘图上找轮廓
        size = contours.size();
        //ROS_DEBUG("detecting contour size is: %d", size);
        for (int i = 0; i < contours.size(); ++i) {
            area = cv::contourArea(contours[i]); //计算每个轮廓的面积
            //ROS_DEBUG("contour area is: %f", area);
            if (area > THRESHOLD) //只有当轮廓大于一定阈值时,才被考虑为瓷砖的轮廓,否则则为噪点的轮廓,不予以考虑
            {
                good_contours.push_back(contours[i]);
            }
        }
        //cout<<good_contours.size()<<endl;
        //imshow("feature", edges);
        //waitKey(0);
        if(good_contours.empty())
        {
            cerr<<"无法识别轮廓！"<<endl;
            continue;
        }
        int max=good_contours[0].size();
        for(int i=0;i<good_contours.size();i++)
        {
            if(max<good_contours[i].size())
                max=good_contours[i].size();
        }
        //提取轮廓的端点，通过端点判断

        vector<Point3d> couner;
        for (int i = 0; i < good_contours.size(); i++) {
            //couner.emplace_back(good_contours[i].end()->x,good_contours[i].end()->y,i);
            if(good_contours[i].size()<max*0.3)
                continue;
            int n=good_contours[i].size();
            couner.emplace_back(good_contours[i].front().x,good_contours[i].front().y,i*2);//放的轮廓起始点
            couner.emplace_back(good_contours[i][n/2].x,good_contours[i][n/2].y,i*2+1);//放的轮廓中间点，可能是断点
            //cout<<*good_contours[i].begin()<<endl;
            //circle(image,*good_contours[i].begin(), 50, Scalar(0,0,0));
        }
///第一种方法,未考虑垂直水平，还需要加上线段垂直水平的条件算法
        //首先将每个轮廓归为一个contours
        vector<Point> ij=complete(edges,couner);//确定距离最近的点,输出couner中点对应的索引编号
        vector<vector<Point>> update_good_contour;
        vector<vector<Point>> good_contour_copy;
        vector<Point> temp;
        good_contour_copy=good_contours;
        for(int i=0;i<ij.size();i++)
        {
            if(good_contours[ij[i].x].front().x==0&&good_contours[ij[i].y/2].front().x==0)
            {
                if(good_contours[ij[i].x].front().y<good_contours[ij[i].y/2].front().y)
                {
                    temp=good_contours[ij[i].x];//提出ij对应的第一个点对应的向量
                    for(int j=0;j<good_contours[ij[i].y/2].size();j++)
                    {
                        temp.push_back(good_contours[ij[i].y/2][j]);//提出ij对应的第二个点对应的向量把与索引i对应点距离较小的索引都放到temp里面去。

                    }
                    continue;
                } else
                {
                    temp=good_contours[ij[i].y/2];//提出ij对应的第一个点对应的向量
                    for(int j=0;j<good_contours[ij[i].x].size();j++)
                    {
                        temp.push_back(good_contours[ij[i].x][j]);//提出ij对应的第二个点对应的向量把与索引i对应点距离较小的索引都放到temp里面去。

                    }
                    continue;
                }
            }
            if(good_contours[ij[i].x].front().x==image.cols&&good_contours[ij[i].y/2].front().x==image.cols)
            {
                if(good_contours[ij[i].x].front().y<good_contours[ij[i].y/2].front().y)
                {
                    temp=good_contours[ij[i].x];//提出ij对应的第一个点对应的向量
                    for(int j=0;j<good_contours[ij[i].y/2].size();j++)
                    {
                        temp.push_back(good_contours[ij[i].y/2][j]);//提出ij对应的第二个点对应的向量把与索引i对应点距离较小的索引都放到temp里面去。

                    }
                    continue;
                } else
                {
                    temp=good_contours[ij[i].y/2];//提出ij对应的第一个点对应的向量
                    for(int j=0;j<good_contours[ij[i].x].size();j++)
                    {
                        temp.push_back(good_contours[ij[i].x][j]);//提出ij对应的第二个点对应的向量把与索引i对应点距离较小的索引都放到temp里面去。

                    }
                    continue;
                }
            }
            if(good_contours[ij[i].x].front().y==0&&good_contours[ij[i].y/2].front().y==0)
            {
                if(good_contours[ij[i].x].front().x<good_contours[ij[i].y/2].front().x)
                {
                    temp=good_contours[ij[i].x];//提出ij对应的第一个点对应的向量
                    for(int j=0;j<good_contours[ij[i].y/2].size();j++)
                    {
                        temp.push_back(good_contours[ij[i].y/2][j]);//提出ij对应的第二个点对应的向量把与索引i对应点距离较小的索引都放到temp里面去。

                    }
                    continue;
                } else
                {
                    temp=good_contours[ij[i].y/2];//提出ij对应的第一个点对应的向量
                    for(int j=0;j<good_contours[ij[i].x].size();j++)
                    {
                        temp.push_back(good_contours[ij[i].x][j]);//提出ij对应的第二个点对应的向量把与索引i对应点距离较小的索引都放到temp里面去。

                    }
                    continue;
                }
            }
            if(good_contours[ij[i].x].front().y==image.rows&&good_contours[ij[i].y/2].front().y==image.rows)
            {
                if(good_contours[ij[i].x].front().x<good_contours[ij[i].y/2].front().x)
                {
                    temp=good_contours[ij[i].x];//提出ij对应的第一个点对应的向量
                    for(int j=0;j<good_contours[ij[i].y/2].size();j++)
                    {
                        temp.push_back(good_contours[ij[i].y/2][j]);//提出ij对应的第二个点对应的向量把与索引i对应点距离较小的索引都放到temp里面去。

                    }
                    continue;
                } else
                {
                    temp=good_contours[ij[i].y/2];//提出ij对应的第一个点对应的向量
                    for(int j=0;j<good_contours[ij[i].x].size();j++)
                    {
                        temp.push_back(good_contours[ij[i].x][j]);//提出ij对应的第二个点对应的向量把与索引i对应点距离较小的索引都放到temp里面去。

                    }
                    continue;
                }
            }
            temp=good_contours[ij[i].x];//提出ij对应的第一个点对应的向量
            for(int j=0;j<good_contours[ij[i].y/2].size();j++)
            {
                temp.push_back(good_contours[ij[i].y/2][j]);//提出ij对应的第二个点对应的向量把与索引i对应点距离较小的索引都放到temp里面去。

            }
            cout<<good_contours[ij[i].y/2].front()<<endl;
            cout<<temp.front()<<endl;
            update_good_contour.push_back(temp);
            good_contour_copy[ij[i].x].clear();
            good_contour_copy[ij[i].y/2].clear();
        }
        for(int i=0;i<good_contour_copy.size();i++)
        {
            if(good_contour_copy[i].size()!=0)
            {
                update_good_contour.push_back(good_contour_copy[i]);
            }
        }
        cout<<update_good_contour[0].size()<<endl;
        ///拟合成直线。

        vector<Point> fit_point1;
        vector<Point> fit_point2;
        float k_1(0) ;
        float b_1(0) ;
        float k_2(0);
        float b_2(0) ;
        Mat image1(edges.rows,edges.cols,CV_8UC1);
        image1=Scalar(0);
        for(int j=0;j<update_good_contour.size();j++)
        {
            Point mcenter;
            int n;
            Mat image0(edges.rows,edges.cols,CV_8UC1);
            image0=Scalar(0);
            drawContours(image0, update_good_contour, j, Scalar(255));
            findContours(image0, contours, hierarchy, RETR_EXTERNAL, CHAIN_APPROX_NONE); //在边缘图上找轮廓
            imshow("feature", image0);
            waitKey(0);
            for(int j=0;j<contours[0].size();j++)
            {
                mcenter+=contours[0][j];
            }
            n=contours[0].size();
            mcenter/=n;
            ////第二种提取直线
            for (int i = 0; i < contours[0].size(); i++) {
                if (i < contours[0].size() / 8)
                    fit_point1.push_back(contours[0][i]);
                else if (i >= 7 * contours[0].size() / 8)
                    fit_point2.push_back(contours[0][i]);
            }
            Vec4f fitted_point1, fitted_point2;
            Point x_1, x_2, x_3, x_4;
            fitLine(fit_point1, fitted_point1, DIST_HUBER, 0, 0.01, 0.01);
            fitLine(fit_point2, fitted_point2, DIST_HUBER, 0, 0.01, 0.01);

            k_1 = fitted_point1[1] / fitted_point1[0];
            b_1 = fitted_point1[3] - k_1 * fitted_point1[2];
            k_2 = fitted_point2[1] / fitted_point2[0];
            b_2 = fitted_point2[3] - k_2 * fitted_point2[2];

            if(k_1>1.3||(k_1>-0.5&&k_1<0))///判断斜率阈值
            {

                fit_point1.clear();
                for (int i = 0; i < contours[0].size() / 2; i++) {
                    if(i>=contours[0].size() / 16&&i<=3*contours[0].size() / 16)
                        fit_point1.push_back(contours[0][i]);
                }
                fitLine(fit_point1, fitted_point1, DIST_HUBER, 0, 0.01, 0.01);
                k_1 = fitted_point1[1] / fitted_point1[0];
                b_1 = fitted_point1[3] - k_1 * fitted_point1[2];
                if(k_1>1.3||(k_1>-0.5&&k_1<0)) {

                    fit_point1.clear();
                    for (int i = 0; i < contours[0].size() / 8; i++) {
                        fit_point1.push_back(contours[0][i]);
                    }
                    fitLine(fit_point1, fitted_point1, DIST_HUBER, 0, 0.01, 0.01);
                    k_1 = fitted_point1[1] / fitted_point1[0];
                    b_1 = fitted_point1[3] - k_1 * fitted_point1[2];
                }
            }
            if(k_2>1.3||(k_2>-0.5&&k_2<0))
            {
                fit_point2.clear();
                for (int i = 0; i < contours[0].size(); i++) {
                    if(i>=15*contours[0].size() / 16)
                        fit_point2.push_back(contours[0][i]);
                }
                fitLine(fit_point2, fitted_point2, DIST_HUBER, 0, 0.01, 0.01);
                k_2 = fitted_point2[1] / fitted_point2[0];
                b_2 = fitted_point2[3] - k_2 * fitted_point2[2];
                if(k_2>1.3||(k_2>-0.5&&k_2<0))
                {
                    fit_point2.clear();
                    for (int i = 0; i < contours[0].size(); i++) {
                        if(i>=29*contours[0].size() / 32&&i<31 * contours[0].size() / 32)
                            fit_point2.push_back(contours[0][i]);
                    }
                    fitLine(fit_point2, fitted_point2, DIST_HUBER, 0, 0.01, 0.01);
                    k_2 = fitted_point2[1] / fitted_point2[0];
                    b_2 = fitted_point2[3] - k_2 * fitted_point2[2];
                }
            }
            if(k_1*k_2>0)
            {
                fit_point2.clear();
                for (int i = 0; i < contours[0].size(); i++) {
                    if(i<7*contours[0].size() / 8&&i>=3 * contours[0].size() / 4)
                        fit_point2.push_back(contours[0][i]);
                }
                fitLine(fit_point2, fitted_point2, DIST_HUBER, 0, 0.01, 0.01);
                k_2 = fitted_point2[1] / fitted_point2[0];
                b_2 = fitted_point2[3] - k_2 * fitted_point2[2];
                if(k_1*k_2>0)
                {
                    fit_point2.clear();
                    for (int i = 0; i < contours[0].size(); i++) {
                        if(i<=5*contours[0].size() / 8&&i>1 * contours[0].size() / 2)
                            fit_point2.push_back(contours[0][i]);
                    }
                    fitLine(fit_point2, fitted_point2, DIST_HUBER, 0, 0.01, 0.01);
                    k_2 = fitted_point2[1] / fitted_point2[0];
                    b_2 = fitted_point2[3] - k_2 * fitted_point2[2];
                }
                if(k_1*k_2>0)
                {
                    fit_point2.clear();
                    for (int i = 0; i < contours[0].size(); i++) {
                        if(i>=5*contours[0].size() / 8&&i<3 * contours[0].size() / 4)
                            fit_point2.push_back(contours[0][i]);
                    }
                    fitLine(fit_point2, fitted_point2, DIST_HUBER, 0, 0.01, 0.01);
                    k_2 = fitted_point2[1] / fitted_point2[0];
                    b_2 = fitted_point2[3] - k_2 * fitted_point2[2];
                }
                if(k_1*k_2>0)
                {
                    continue;
                }
            }

            x_1.x = cvRound(fitted_point1[2] - 500);
            x_1.y = cvRound(k_1 * x_1.x + b_1);
            x_2.x = cvRound(fitted_point1[2] + 500);
            x_2.y = cvRound(k_1 * x_2.x + b_1);

            x_3.x = cvRound(fitted_point2[2] - 1000);
            x_3.y = cvRound(k_2 * x_3.x + b_2);
            x_4.x = cvRound(fitted_point2[2] + 1000);
            x_4.y = cvRound(k_2 * x_4.x + b_2);

            fit_point1.clear();
            fit_point2.clear();

            vector<Point2d> intersection1;//保存交点
            vector<Point2d> intersection2;//保存交点
            vector<Point2d> intersection3;//保存交点
            intersection1.resize(2);
            intersection2.resize(2);
            intersection1=compute_xy(image0,k_1,b_1);//计算直线与图像边缘的交点
            intersection2=compute_xy(image0,k_2,b_2);//计算直线与图像边缘的交点
            if(k_1*k_2>0)
            {
                continue;
            }
            Point2d inter((b_2-b_1)/(k_1-k_2),((b_2-b_1)/(k_1-k_2)*k_1+b_1+(b_2-b_1)/(k_1-k_2)*k_2+b_2)/2);
            vector<vector<Point2d>> intersection_area;
            intersection_area.resize(4);
            int count(0);
            for(int i=0;i<intersection1.size();i++)
            {
                for(int j=0;j<intersection2.size();j++)
                {
                    intersection_area[count].push_back(intersection1[i]);
                    intersection_area[count].push_back(inter);
                    intersection_area[count].push_back(intersection2[j]);
                    count++;
                }
            }


            //计算周长
            int nt(0);
            float length_true=arcLength(contours[0],-1);//计算contours的周长
            for(int i=0;i<intersection_area.size();i++)
            {
                float a=distancepoint(intersection_area[i][0],intersection_area[i][1]);
                float b=distancepoint(intersection_area[i][0],intersection_area[i][2]);
                float c=distancepoint(intersection_area[i][1],intersection_area[i][2]);
                float p=(a+b+c);
                if(p/length_true>0.8&&p/length_true<1.2)
                {
                    intersection3.push_back(intersection1[i/2]);
                    intersection3.push_back(intersection2[i%2]);
                    nt++;
                }
            }
            if(nt>1)//计算距离
            {
                //intersection1.insert(intersection1.end(),intersection2.begin(),intersection2.end());//所有与图像边缘相交的点
                for(int i=0;i<intersection3.size();i++)
                {
                    intersection1.push_back(intersection3[i]);
                }
                intersection2.clear();
                vector<float> dist;
                float d;
                for(int i=0;i<intersection1.size();i+=2)
                {
                    dist.push_back((distancepoint(intersection1[i],Point2d(mcenter.x,mcenter.y))+distancepoint(intersection1[i+1],Point2d(mcenter.x,mcenter.y))));
                }
                int flag;
                float min=dist[0];
                for(int i=0;i<dist.size();i++)
                {
                    if(min>dist[i])
                    {
                        min=dist[i];
                        flag=i;
                    }
                }

                intersection2.push_back(intersection1[flag*2]);
                intersection2.push_back(intersection1[flag*2+1]);
                line(image1, intersection2[0], inter, Scalar(255), 1);
                line(image1, intersection2[1], inter, Scalar(255), 1);
            } else
            {
                line(image1, intersection3[0], inter, Scalar(255), 1);
                line(image1, intersection3[1], inter, Scalar(255), 1);
            }

            intersection1.clear();
            intersection2.clear();
            intersection3.clear();
            intersection_area.clear();
        }

        imshow("feature", image1);
        waitKey(0);
        good_contours.clear();
       //// couner.clear();

///第一种方法的参数更新

       update_good_contour.clear();
       good_contour_copy.clear();
       ij.clear();
       temp.clear();

        //couner.clear();
    }
    return 0;
}
