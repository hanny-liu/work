#include <iostream>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/calib3d.hpp>
using namespace std;


int main() {
    cv::Mat src = cv::imread("1.jpg");
    if (!src.data)
        { cout << "error" << endl; return -1; }
    cv::Mat temp,dst; //先进行边缘检测
    cv::Canny(src, temp, 50, 200, 3);
    //转化检测后的图为3通道
    cv::cvtColor(temp, dst, cv::COLOR_GRAY2BGR);
    std::vector<cv::Vec4i>lines;//用于存放得到的线段矢量集合
    // 进行霍夫线变换
    cv::HoughLinesP(temp, //输入图像，为单通道二进制图像
                    lines, //检测到的线段矢量 1, //以像素为单位的距离精度
                    CV_PI / 180, //以弧度为单位的角度精度
                    80, //累加平面的阙值参数
                    50, //最低线段的长度
                    10);//允许将同一行点与点之间连接起来的最大距离 //依次绘制出每条线段
    for (size_t i = 0; i < lines.size(); i++)
        {
            cv::Vec4i l=lines[i];
            cv::line(dst, cv::Point(l[0], l[1]), cv::Point(l[2], l[3]), cv::Scalar(186, 88, 255), 1,CV_AA);
        }
    cv::imshow("原图", src);
    cv::imshow("HoughLinesP 效果图", dst);
    cv::waitKey(0);

}