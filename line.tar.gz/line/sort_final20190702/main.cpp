#include <iostream>
#include <opencv4/opencv2/calib3d.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/calib3d.hpp>
#include <opencv2/imgcodecs.hpp>
#include <vector>
#include <algorithm>
using std::random_shuffle;
using namespace std;
using namespace cv;
//针对正常情况的标志位
const int NORMAL = 0;
//针对非正常情况的标志位
const int ABNORMAL = 1;
//针对不考虑情况的标志位
const int WTF = -1;
//代表移动瓷砖
const int MOVE = 1;
//代表静止瓷砖
const int STATIC = 0;
//高斯模糊的滤波器大小
const int KERNEL = 5;
//高斯滤波x方向方差
const double SIGMAX = 3.0;
//高斯滤波y方向方差
const double SIGMAY = 3.0;
//边缘检测canny用的低阈值
const int LOW_THRESHOLD = 80;
///const int LOW_THRESHOLD = 100;
//边缘检测canny用的高阈值
const int HIGH_THRESHOLD = 200;
//轮廓滤波时的阈值,面积小于此数值的轮廓会被过滤掉
const double THRESHOLD = 100.0;
//霍夫变换时的阈值
///const int H_THRESHOLD = 50;
const int H_THRESHOLD = 100;
//画线时线的粗细度
const int THICKNESS = 1;
//画线的通道连接
const int LINETYPE = 8;
//画圆时圆的半径
const int RADIUS = 8;
//霍夫变换距离解析度
const double HOUGH_RHO = 1;
//霍夫变换角度解析度
const double HOUGH_THETA = CV_PI / 180;
//定义离静止瓷砖角点的距离
const int distance = 50;
//定义离静止pylon获取图像时最大缓存
const int MAX_BUFFER = 5;
//定义经过去畸变后的图像的宽
const int WIDTH = 757;
//定义经过去畸变后图像的高
const int HEIGHT = 537;
//定义一共抓取多少张图片;
const uint32_t C_COUNTOFIMAES = 10;


template <typename T>
float distancepoint(const T & p1,const T & p2)
{
    float x_=p1.x-p2.x;
    float y_=p1.y-p2.y;
    float d=pow((x_*x_+y_*y_),0.5);
    return d;
}

vector<Point> complete(Mat &edges,vector<Point3d> &couner) {
    //Point ij1, ij2;
    vector<Point> ij;
    copyMakeBorder(edges, edges, 1, 1, 1, 1, BORDER_CONSTANT);//扩充图片边界
    for (int i = 0; i < couner.size(); i+=2) {
        for (int j = (couner.size()-1) /2; j > i/2; j--) {
            float d1=distancepoint(couner[i],couner[j*2]);
            float d2=distancepoint(couner[i],couner[j*2+1]);
            float d3=distancepoint(couner[i+1],couner[j*2]);
            float d4=distancepoint(couner[i+1],couner[j*2+1]);
            if(d1<=10&&couner[i]!=couner[j*2]&&couner[i].z!=couner[j*2].z)
            {
                ij.emplace_back(i/2,j*2);
            }
            if(d2<=10&&couner[i]!=couner[j*2+1]&&couner[i].z!=couner[j*2+1].z)
            {
                ij.emplace_back(i/2,j*2+1);
            }
            if(d3<=10&&couner[i+1]!=couner[j*2]&&couner[i+1].z!=couner[j*2].z)
            {
                ij.emplace_back(i/2,j*2);
            }
            if(d4<=10&&couner[i+1]!=couner[j*2+1]&&couner[i+1].z!=couner[j*2+1].z)
            {
                ij.emplace_back(i/2,j*2+1);
            }
            //if (distancepoint(couner[i], couner[j]) <= 50&&couner[i]!=couner[j]&&couner[i].z!=couner[j].z)///条件需要考量
            //{
               // ij.emplace_back(i,j);
                /***
                int t1 = couner[i].x - couner[j].x;
                int t2 = couner[i].y - couner[j].y;
                ij1 = search(edges, couner[i]);
                ij2 = search(edges, couner[j]);
                Point ci = couner[i];
                Point cj = couner[j];
                if (abs(t1) == abs(t2)) {
                    for (int i = 0; i < abs(t1); i++)///需要考虑t1和t2的符号
                    {
                        edges.at<uchar>(ci.y - ij1.y * i, ci.x - ij1.x * i) = 255;
                        edges.at<uchar>(cj.y - ij2.y * i, cj.x - ij2.x * i) = 255;
                    }

                } else if (couner[i].x == couner[j].x || couner[i].y == couner[j].y) {
                    if (t1 != 0)///需要考虑t1和t2的符号
                    {
                        for (int i = 0; i < abs(t1); i++)
                        {
                            edges.at<uchar>(ci.y - ij1.y, ci.x - ij1.x) = 255;
                            edges.at<uchar>(cj.y - ij2.y, cj.x - ij2.x) = 255;
                        }
                    } else {
                        for (int i = 0; i < abs(t2); i++)///需要考虑t1和t2的符号
                        {
                            edges.at<uchar>(ci.y - ij1.y, ci.x - ij1.x) = 255;
                            edges.at<uchar>(cj.y - ij2.y, cj.x - ij2.x) = 255;
                        }
                    }

                } else {
                    float k1=ij1.y/ij1.x;
                    float b1=couner[i].y-couner[i].x*k1;
                    float k2=ij2.y/ij2.x;
                    float b2=couner[j].y-couner[j].x*k2;
                    float x3 = (b2-b1)/(k2-k1);
                    float y3=k1*x3+b1;
                    float x1 = couner[i].x;
                    float y1 = couner[i].y;
                    float x2 = couner[j].x;
                    float y2 = couner[j].y;
                    float x_13=abs(x1-x3);
                    float y_13=abs(y1-y3);
                    float x_23=abs(x2-x3);
                    float y_23=abs(y2-y3);
                    if(x_13<=y_13)
                    {
                        for (int i = 0; i < x_13; i++)
                        {
                            edges.at<uchar>(y1 - ij1.y * i, x1 - ij1.x * i) = 255;
                        }
                    } else
                    {
                        for (int i = 0; i < y_13; i++)
                        {
                            edges.at<uchar>(y1 - ij1.y * i, x1 - ij1.x * i) = 255;
                        }
                    }
                    if(x_23<=y_23)
                    {
                        for (int i = 0; i < x_23; i++)
                        {
                            edges.at<uchar>(y2 - ij2.y * i, x2 - ij2.x * i) = 255;
                        }
                    } else
                    {
                        for (int i = 0; i < y_23; i++)
                        {
                            edges.at<uchar>(y2 - ij2.y * i, x2 - ij2.x * i) = 255;
                        }
                    }
                    ***/
                    /**
                    float c = distancepoint(couner[i], couner[j]);
                    int x3 = couner[j].x;
                    int y3 = couner[i].y - x3 + couner[i].x;
                    float xi = couner[i].x;
                    float yi = couner[i].y;
                    float xj = couner[j].x;
                    float yj = couner[j].y;
                    float a = abs(-x3 + couner[i].x);
                    Point E(couner[i].x - ij1.x * a / 2.0, couner[i].y - ij1.y * a / 2.0);//缺失角点
                    edges.at<uchar>(couner[i].y - ij1.y * a / 2.0, couner[i].x - ij1.x * a / 2.0) = 255;

                    for (int i = 0; i < abs(ij1.x * a / 2.0); i++)
                    {
                        edges.at<uchar>(yi - ij1.y * i, xi - ij1.x * i) = 255;
                    }
                    float t1 = couner[i].x - ij1.x * a / 2.0 - xj;
                    for (int i = 0; i < abs(t1); i++)
                    {
                        edges.at<uchar>(yj + ij2.y * i, xj + ij2.x * i) = 255;
                    }**/
            //}

            }
        }
    return ij;
    }

vector<Point2d> compute_k_center(vector<vector<Point2d>> & k_means)
{
    vector<Point2d> k_center1;
    k_center1.resize(k_means.size());
    float av_x(0), av_y(0);
    for (int i = 0; i < k_means.size(); i++) {
        for (auto j:k_means[i]) {
            av_x += j.x;
            av_y += j.y;
        }
        k_center1[i].x = av_x / k_means[i].size();
        k_center1[i].y = av_y / k_means[i].size();
    }
    return k_center1;
}


vector<Vec2f> hough_extract(Mat &image0)
{
    vector<Vec2f> plines;
    vector<Vec2f> result;
    HoughLines(image0, plines,HOUGH_RHO, HOUGH_THETA, H_THRESHOLD);
    vector<vector<Point>> p1p2;
    p1p2.resize(plines.size());
    for(int i=0;i<plines.size();i++)
    {
        auto hline=plines[i];
        float rho = hline[0], theta = hline[1];
        Point pt1, pt2;
        double a = cos(theta), b = sin(theta);
        double x0 = a*rho, y0 = b*rho;
        pt1.x = cvRound(x0 + 1000*(-b));
        pt1.y = cvRound(y0 + 1000*(a));
        pt2.x = cvRound(x0 - 1000*(-b));
        pt2.y = cvRound(y0 - 1000*(a));
        p1p2[i].push_back(pt1);
        p1p2[i].push_back(pt2);
        //line( image, pt1, pt2, Scalar(0,0,255), 3);
        //line(image, Point(0, 0), Point(hline[0]*cos(hline[1]),hline[0]*sin(hline[1]) ), Scalar(0), 1, LINE_AA);
    }
    //imshow("feature", image);
    //waitKey(0);
    float xl1(0);
    float xl2(0);
    Vec2f xl_1(0,0);
    Vec2f xl_2(0,0);
    Point p1(0,0),p2(0,0);
    int n1(0),n2(0);
    //vector<Point> fit_point1;
    //vector<Point> fit_point2;

    if(plines.size()==1)//只识别出一条有斜率的线，或者是相同斜率的线
    {
        if((p1p2[0][0].y-p1p2[0][1].y)/(p1p2[0][0].x-p1p2[0][1].x)<0)
        {
            vector<Vec2f> x;
            x.push_back(plines[0]);
            return x;
        } else
        {
            vector<Vec2f> x;
            return x;
        }

    }
    for(int i=0;i<=p1p2.size()-2;i+=2)
    {
        xl1=float(p1p2[i][1].y-p1p2[i][0].y)/float(p1p2[i][1].x-p1p2[i][0].x);
        xl2=float(p1p2[i+1][1].y-p1p2[i+1][0].y)/float(p1p2[i+1][1].x-p1p2[i+1][0].x);
        if(xl1*xl2<0)
        {
            if(xl1>0&&xl2<0)
            {
                xl_1+=plines[i];
                xl_2+=plines[i+1];
                //fit_point1.push_back(p1p2[i][0]);
                //fit_point1.push_back(p1p2[i][1]);
                //fit_point2.push_back(p1p2[i+1][0]);
                //fit_point2.push_back(p1p2[i+1][1]);
                n1++;
                n2++;
            }
            else
            {
                xl_1+=plines[i+1];
                xl_2+=plines[i];
                //fit_point2.push_back(p1p2[i][0]);
                //fit_point2.push_back(p1p2[i][1]);
                //fit_point1.push_back(p1p2[i+1][0]);
                //fit_point1.push_back(p1p2[i+1][1]);
                n1++;
                n2++;
            }
        } else
        {
            if(xl1>=0)
            {
                xl_1+=plines[i]+plines[i+1];
                //fit_point1.push_back(p1p2[i][0]);
                //fit_point1.push_back(p1p2[i][1]);
                //fit_point1.push_back(p1p2[i+1][0]);
                //fit_point1.push_back(p1p2[i+1][1]);
                n1+=2;
            }
            else
            {
                xl_2+=plines[i+1]+plines[i];
                //fit_point2.push_back(p1p2[i][0]);
                //fit_point2.push_back(p1p2[i][1]);
                //fit_point2.push_back(p1p2[i+1][0]);
                //fit_point2.push_back(p1p2[i+1][1]);
                n2+=2;
            }
        }
    }
    if(n1==0)
    {
        xl_2/=n2;
        plines.clear();
        plines.resize(1);
        plines[0]=Vec2f(-1,-1);
        return plines;
    }
    else if(n2==0)
    {
        xl_1/=n1;
        plines.clear();
        plines.resize(1);
        plines[0]=Vec2f(-1,-1);
        return plines;
    }
    else
    {
        xl_1/=n1;
        xl_2/=n2;
        vector<Vec2f> x;
        x.push_back(xl_1);
        x.push_back(xl_2);
        float rho1 = xl_1[0], theta1 = xl_1[1];
        float rho2 = xl_2[0], theta2 = xl_2[1];
        Point pt1, pt2,pt3,pt4;
        double a1 = cos(theta1), b1 = sin(theta1);
        double x0 = a1*rho1, y0 = b1*rho1;
        pt1.x = cvRound(x0 + 1000*(-b1));
        pt1.y = cvRound(y0 + 1000*(a1));
        pt2.x = cvRound(x0 - 1000*(-b1));
        pt2.y = cvRound(y0 - 1000*(a1));
        double a2 = cos(theta2), b2 = sin(theta2);
        double x2 = a2*rho2, y2 = b2*rho2;
        pt3.x = cvRound(x2 + 1000*(-b2));
        pt3.y = cvRound(y2 + 1000*(a2));
        pt4.x = cvRound(x2 - 1000*(-b2));
        pt4.y = cvRound(y2 - 1000*(a2));
        //circle( image,pt1, 10, Scalar(255));
        //cMatircle( image,p1, 10, Scalar(255));
        //pt2.x = cvRound(x0 - 1000*(-b));
        //pt2.y = cvRound(y0 - 1000*(a));
        ///进行直线拟合
       // Vec4f fitted_point1,fitted_point2;
       // Point x_1,x_2,x_3,x_4;
        //fitLine(fit_point1,fitted_point1,DIST_HUBER  ,0,0.01,0.01);
        //fitLine(fit_point2,fitted_point2,DIST_HUBER  ,0,0.01,0.01);
        //float k_1=fitted_point1[1]/fitted_point1[0];
        //float b_1=fitted_point1[3]-k_1*fitted_point1[2];
        //float k_2=fitted_point2[1]/fitted_point2[0];
        //float b_2=fitted_point2[3]-k_1*fitted_point2[2];

        //x_1.x=cvRound(fitted_point1[2]-500);
        //x_1.y=cvRound(k_1*x_1.x+b_1);
        //x_2.x=cvRound(fitted_point1[2]+500);
        //x_2.y=cvRound(k_1*x_2.x+b_1);

        //x_3.x=cvRound(fitted_point2[2]-500);
        //x_3.y=cvRound(k_2*x_3.x+b_2);
        //x_4.x=cvRound(fitted_point2[2]+500);
        //x_4.y=cvRound(k_2*x_4.x+b_2);

        line( image0, pt1, pt2, Scalar(255), 1);
        line( image0, pt3, pt4, Scalar(255), 1);
        //cout<<"plines:"<<plines.size()<<endl;
        return x;
    }

}

vector<Point2d> compute_xy(Mat & image,float k,float b)
{
    vector<Point2d> intersection;
    float x1,x2,y1,y2,x3,y3,x4,y4;
    x1=0;
    y1=k*x1+b;
    x2=image.cols;
    y2=k*x2+b;
    y3=0;
    x3=(y3-b)/k;
    y4=image.rows;
    x4=(y4-b)/k;
    if(y1<0||y1>image.rows)
    {
        if(y2<0||y2>image.rows)
        {
            intersection.emplace_back(x3,y3);
            intersection.emplace_back(x4,y4);
        } else
        {
            intersection.emplace_back(x2,y2);
            if(x3<0||x3>image.cols)
                intersection.emplace_back(x4,y4);
            else
                intersection.emplace_back(x3,y3);
        }
    } else
    {
        intersection.emplace_back(x1,y1);
        if(y2<0||y2>image.rows)
        {
            if(x3<0||x3>image.cols)
                intersection.emplace_back(x4,y4);
            else
                intersection.emplace_back(x3,y3);
        } else
        {
            intersection.emplace_back(x2,y2);
        }
    }
    return intersection;
}


int main()
{

    cv::Mat blur;
    cv::Mat edges;
    vector<vector<cv::Point>> contours;
    vector<cv::Vec4i> hierarchy;
    vector<vector<cv::Point>> good_contours;
    cv::Mat image;
    cv::Mat median;
    double area;
    int size;
    vector<Mat> img;
    string file;
    for (int i = 1; i < 40; i++) {
        
        file = "/home/lhw/lhw/工作/cv_test2/before_" + to_string(i) + ".jpg";
        image = imread(file);
        img.push_back(image);
    }
    int quantity(0);
    for (int l =23 ; l < img.size(); l++)
    {
        quantity++;
        cout<<"第"<<quantity<<"次"<<endl;

        image=img[l];

        resize(image,image,Size(700,500));
        GaussianBlur(image, blur, cv::Size(KERNEL, KERNEL), SIGMAX, SIGMAY); //高斯模糊,去除小噪点,同时让图像边平滑
        medianBlur( blur, blur ,9 );
        Canny(blur, edges, LOW_THRESHOLD, HIGH_THRESHOLD);                   //边缘检测,canny算法
        findContours(edges, contours, hierarchy, RETR_EXTERNAL, CHAIN_APPROX_NONE); //在边缘图上找轮廓
        size = contours.size();

        for (int i = 0; i < contours.size(); ++i) {
            area = cv::contourArea(contours[i]); //计算每个轮廓的面积
            if (area > THRESHOLD) //只有当轮廓大于一定阈值时,才被考虑为瓷砖的轮廓,否则则为噪点的轮廓,不予以考虑
            {
                good_contours.push_back(contours[i]);
            }
        }
        //for(int i=0;i<good_contours.size();i++)
        //   drawContours(image, good_contours, i, Scalar(255));
        //imshow("feature", image);
        //waitKey(0);
        if(good_contours.empty())
        {
            cerr<<"无法识别轮廓！"<<endl;
            continue;
        }
        int max=good_contours[0].size();
        for(int i=0;i<good_contours.size();i++)
        {
            if(max<good_contours[i].size())
                max=good_contours[i].size();
        }
        //提取轮廓的端点，通过端点判断

        vector<Point3d> couner;
        for (int i = 0; i < good_contours.size(); i++) {
            if(good_contours[i].size()<max*0.3)
                continue;
            int n=good_contours[i].size();
            couner.emplace_back(good_contours[i].front().x,good_contours[i].front().y,i*2);//放的轮廓起始点
            couner.emplace_back(good_contours[i][n/2].x,good_contours[i][n/2].y,i*2+1);//放的轮廓中间点，可能是断点
        }
///第一种方法,未考虑垂直水平，还需要加上线段垂直水平的条件算法
        //首先将每个轮廓归为一个contours
        vector<Point> ij=complete(edges,couner);//确定距离最近的点,输出couner中点对应的索引编号
        vector<vector<Point>> update_good_contour;
        vector<vector<Point>> good_contour_copy;
        vector<Point> temp;
        good_contour_copy=good_contours;
        for(int i=0;i<ij.size();i++)
        {
            if(good_contours[ij[i].x].front().x==0&&good_contours[ij[i].y/2].front().x==0)
            {
                if(good_contours[ij[i].x].front().y<good_contours[ij[i].y/2].front().y)
                {
                    temp=good_contours[ij[i].x];//提出ij对应的第一个点对应的向量
                    for(int j=0;j<good_contours[ij[i].y/2].size();j++)
                    {
                        temp.push_back(good_contours[ij[i].y/2][j]);//提出ij对应的第二个点对应的向量把与索引i对应点距离较小的索引都放到temp里面去。

                    }
                    continue;
                } else
                {
                    temp=good_contours[ij[i].y/2];//提出ij对应的第一个点对应的向量
                    for(int j=0;j<good_contours[ij[i].x].size();j++)
                    {
                        temp.push_back(good_contours[ij[i].x][j]);//提出ij对应的第二个点对应的向量把与索引i对应点距离较小的索引都放到temp里面去。

                    }
                    continue;
                }
            }
            if(good_contours[ij[i].x].front().x==image.cols&&good_contours[ij[i].y/2].front().x==image.cols)
            {
                if(good_contours[ij[i].x].front().y<good_contours[ij[i].y/2].front().y)
                {
                    temp=good_contours[ij[i].x];//提出ij对应的第一个点对应的向量
                    for(int j=0;j<good_contours[ij[i].y/2].size();j++)
                    {
                        temp.push_back(good_contours[ij[i].y/2][j]);//提出ij对应的第二个点对应的向量把与索引i对应点距离较小的索引都放到temp里面去。

                    }
                    continue;
                } else
                {
                    temp=good_contours[ij[i].y/2];//提出ij对应的第一个点对应的向量
                    for(int j=0;j<good_contours[ij[i].x].size();j++)
                    {
                        temp.push_back(good_contours[ij[i].x][j]);//提出ij对应的第二个点对应的向量把与索引i对应点距离较小的索引都放到temp里面去。

                    }
                    continue;
                }
            }
            if(good_contours[ij[i].x].front().y==0&&good_contours[ij[i].y/2].front().y==0)
            {
                if(good_contours[ij[i].x].front().x<good_contours[ij[i].y/2].front().x)
                {
                    temp=good_contours[ij[i].x];//提出ij对应的第一个点对应的向量
                    for(int j=0;j<good_contours[ij[i].y/2].size();j++)
                    {
                        temp.push_back(good_contours[ij[i].y/2][j]);//提出ij对应的第二个点对应的向量把与索引i对应点距离较小的索引都放到temp里面去。

                    }
                    continue;
                } else
                {
                    temp=good_contours[ij[i].y/2];//提出ij对应的第一个点对应的向量
                    for(int j=0;j<good_contours[ij[i].x].size();j++)
                    {
                        temp.push_back(good_contours[ij[i].x][j]);//提出ij对应的第二个点对应的向量把与索引i对应点距离较小的索引都放到temp里面去。

                    }
                    continue;
                }
            }
            if(good_contours[ij[i].x].front().y==image.rows&&good_contours[ij[i].y/2].front().y==image.rows)
            {
                if(good_contours[ij[i].x].front().x<good_contours[ij[i].y/2].front().x)
                {
                    temp=good_contours[ij[i].x];//提出ij对应的第一个点对应的向量
                    for(int j=0;j<good_contours[ij[i].y/2].size();j++)
                    {
                        temp.push_back(good_contours[ij[i].y/2][j]);//提出ij对应的第二个点对应的向量把与索引i对应点距离较小的索引都放到temp里面去。

                    }
                    continue;
                } else
                {
                    temp=good_contours[ij[i].y/2];//提出ij对应的第一个点对应的向量
                    for(int j=0;j<good_contours[ij[i].x].size();j++)
                    {
                        temp.push_back(good_contours[ij[i].x][j]);//提出ij对应的第二个点对应的向量把与索引i对应点距离较小的索引都放到temp里面去。

                    }
                    continue;
                }
            }
            temp=good_contours[ij[i].x];//提出ij对应的第一个点对应的向量
            for(int j=0;j<good_contours[ij[i].y/2].size();j++)
            {
                temp.push_back(good_contours[ij[i].y/2][j]);//提出ij对应的第二个点对应的向量把与索引i对应点距离较小的索引都放到temp里面去。

            }
            cout<<good_contours[ij[i].y/2].front()<<endl;
            cout<<temp.front()<<endl;
            update_good_contour.push_back(temp);
            good_contour_copy[ij[i].x].clear();
            good_contour_copy[ij[i].y/2].clear();
        }
        for(int i=0;i<good_contour_copy.size();i++)
        {
            if(good_contour_copy[i].size()!=0)
            {
                update_good_contour.push_back(good_contour_copy[i]);
            }
        }
        cout<<update_good_contour[0].size()<<endl;
        ///先霍夫
        Point mcenter;
        int n;
        vector<Point> point1,point2;
        Point temp1,temp2;
        float residual1,residual2;
        double k_1,k_2,b_1,b_2;
        float rho1 ,theta1 ;
        float rho2, theta2 ;
        Point x_1, x_2, x_3, x_4;
        vector<Point2d> intersection1;//保存交点
        vector<Point2d> intersection2;//保存交点
        vector<Point2d> intersection3;//保存交点
        vector<vector<Point2d>> intersection_area;
        Mat image1(edges.rows,edges.cols,CV_8UC1);
        image1=Scalar(0);

        //存入每次轮廓符合斜率要求的直线
        vector<Point2d> k_b;//存入斜率和b值
        vector<Point> center;
        vector<Vec4f> kb;
        vector<Vec2f> xy;

        /***
        //先判断contours的数量
        if(update_good_contour.size()==2)
        {
            for(int r=0;r<update_good_contour.size();r++)
            {
                Mat image0(edges.rows, edges.cols, CV_8UC1);
                image0 = Scalar(0);
                drawContours(image0, update_good_contour, r, Scalar(255));
                findContours(image0, contours, hierarchy, RETR_EXTERNAL, CHAIN_APPROX_NONE); //在边缘图上找轮廓
                imshow("feature", image0);
                waitKey(0);
                for (int j = 0; j < contours[0].size(); j++) {
                    mcenter += contours[0][j];
                }
                n = contours[0].size();
                mcenter /= n;
                center.push_back(mcenter);
                vector<Vec2f> extract_line=hough_extract(image0);
                rho1 = extract_line[0][0], theta1 = extract_line[0][1];
                rho2 = extract_line[1][0], theta2 = extract_line[1][1];
                k_1=-cos(theta1)/sin(theta1);///需要判别
                k_2 =-cos(theta2)/sin(theta2);///需要判别
                b_1 = rho1/sin(theta1);
                b_2 =rho2/sin(theta2);
                for(int i=0;i<contours[0].size();i++)
                {
                    temp1=contours[0][i];
                    temp1.y=temp1.x*k_1+b_1;
                    temp2=temp1;
                    temp2.y=temp2.x*k_2+b_2;
                    residual1=distancepoint(temp1,contours[0][i]);
                    residual2=distancepoint(temp2,contours[0][i]);
                    if(residual2<3)
                        point2.push_back(contours[0][i]);
                    if(residual1<3)
                        point1.push_back(contours[0][i]);

                }

                Vec4f fitted_point1, fitted_point2;
                fitLine(point1, fitted_point1, DIST_HUBER, 0, 0.01, 0.01);//直线拟合
                k_1 = fitted_point1[1] / fitted_point1[0];
                b_1 = fitted_point1[3] - k_1 * fitted_point1[2];
                fitLine(point2, fitted_point2, DIST_HUBER, 0, 0.01, 0.01);//直线拟合
                k_2 = fitted_point2[1] / fitted_point2[0];
                b_2 = fitted_point2[3] - k_2 * fitted_point2[2];
                xy.emplace_back(fitted_point1[2],fitted_point1[3]);
                xy.emplace_back(fitted_point2[2],fitted_point2[3]);
                kb.emplace_back(k_1,b_1);
                kb.emplace_back(k_2,b_2);
            }
            if(center[0].y>center[1].y)
            {
                if(center[1].x>center[0].x)
                    //取k>0的边
                {
                    if(kb[0][0]>0)
                    {
                        k_b.emplace_back(kb[0][0],kb[0][1],xy[0][0],xy[0][1]);
                        if(kb[2][0]>0)
                            k_b.emplace_back(kb[2][0],kb[2][1],xy[2][0],xy[2][1]);
                        else if(kb[3][0]>0)
                        {
                            k_b.emplace_back(kb[3][0],kb[3][1],xy[3][0],xy[3][1]);
                        }

                    } else if(kb[1][0]>0)
                    {
                        if(kb[2][0]>0)
                            k_b.emplace_back(kb[2][0],kb[2][1],xy[2][0],xy[2][1]);
                        else if(kb[3][0]>0)
                        {
                            k_b.emplace_back(kb[3][0],kb[3][1],xy[3][0],xy[3][1]);
                        }
                    }
                } else
                {
                    if(kb[0][0]<0)
                    {
                        k_b.emplace_back(kb[0][0],kb[0][1],xy[0][0],xy[0][1]);
                        if(kb[2][0]<0)
                            k_b.emplace_back(kb[2][0],kb[2][1],xy[2][0],xy[2][1]);
                        else if(kb[3][0]<0)
                        {
                            k_b.emplace_back(kb[3][0],kb[3][1],xy[3][0],xy[3][1]);
                        }

                    } else if(kb[1][0]<0)
                    {
                        if(kb[2][0]<0)
                            k_b.emplace_back(kb[2][0],kb[2][1],xy[2][0],xy[2][1]);
                        else if(kb[3][0]<0)
                        {
                            k_b.emplace_back(kb[3][0],kb[3][1],xy[3][0],xy[3][1]);
                        }
                    }
                }
            }
            else
            {
                if(center[0].x>center[1].x)
                    //取k>0的边
                {
                    if(kb[0][0]>0)
                    {
                        k_b.emplace_back(kb[0][0],kb[0][1],xy[0][0],xy[0][1]);
                        if(kb[2][0]>0)
                            k_b.emplace_back(kb[2][0],kb[2][1],xy[0][0],xy[0][1]);
                        else if(kb[3][0]>0)
                        {
                            k_b.emplace_back(kb[3][0],kb[3][1],xy[0][0],xy[0][1]);
                        }

                    } else if(kb[1][0]>0)
                    {
                        k_b.emplace_back(kb[1][0],kb[1][1],xy[1][0],xy[1][1]);
                        if(kb[2][0]>0)
                            k_b.emplace_back(kb[2][0],kb[2][1],xy[2][0],xy[2][1]);
                        else if(kb[3][0]>0)
                        {
                            k_b.emplace_back(kb[3][0],kb[3][1],xy[3][0],xy[3][1]);
                        }
                    }
                } else
                {
                    if(kb[0][0]<0)
                    {
                        k_b.emplace_back(kb[0][0],kb[0][1],xy[0][0],xy[0][1]);
                        if(kb[2][0]<0)
                            k_b.emplace_back(kb[2][0],kb[2][1],xy[2][0],xy[2][1]);
                        else if(kb[3][0]<0)
                        {
                            k_b.emplace_back(kb[3][0],kb[3][1],xy[3][0],xy[3][1]);
                        }
                    } else if(kb[1][0]<0)
                    {
                        k_b.emplace_back(kb[1][0],kb[1][1],xy[1][0],xy[1][1]);
                        if(kb[2][0]<0)
                            k_b.emplace_back(kb[2][0],kb[2][1],xy[2][0],xy[2][1]);
                        else if(kb[3][0]<0)
                        {
                            k_b.emplace_back(kb[3][0],kb[3][1],xy[3][0],xy[3][1]);
                        }
                    }
                }
            }

        }

        ***/

        vector<vector<Point2d>> kbp;
        kbp.resize(update_good_contour.size());
        ///第一种提取直线
        for(int r=0;r<update_good_contour.size();r++)
        {
            Mat image0(edges.rows,edges.cols,CV_8UC1);
            image0=Scalar(0);
            drawContours(image0, update_good_contour, r, Scalar(255));
            findContours(image0, contours, hierarchy, RETR_EXTERNAL, CHAIN_APPROX_NONE); //在边缘图上找轮廓
            imshow("feature", image0);
            waitKey(0);
            for(int j=0;j<contours[0].size();j++)
            {
                mcenter+=contours[0][j];
            }
            n=contours[0].size();
            mcenter/=n;
            center.push_back(mcenter);
            //cout<<"contours:"<<contours.size()<<endl;
            //imshow("feature", image0);
            //waitKey(0);
            ///提取霍夫直线完成，image0是画完直线之后的图
            vector<Vec2f> extract_line=hough_extract(image0);
            if(extract_line.size()==1)
            {
                float rho = extract_line[0][0];
                float theta= extract_line[0][1];
                float k =-cos(theta)/sin(theta);///需要判别
                float b = rho/sin(theta);
                k_b.emplace_back(k,b);
            }
            if(extract_line.empty())
                continue;
            if(extract_line[0][0]==-1&&extract_line[0][1]==-1)
            {
                drawContours(image1, contours, 0, Scalar(255));
                imshow("feature", image1);
                waitKey(0);
                continue;
            }
            //imshow("feature", image0);
            //waitKey(0);
            rho1 = extract_line[0][0], theta1 = extract_line[0][1];
            rho2 = extract_line[1][0], theta2 = extract_line[1][1];
            k_1=-cos(theta1)/sin(theta1);///需要判别
            k_2 =-cos(theta2)/sin(theta2);///需要判别
            b_1 = rho1/sin(theta1);
            b_2 =rho2/sin(theta2);
            if(k_2==0||k_1==0)
            {
                continue;
            }
            for(int i=0;i<contours[0].size();i++)
            {
                temp1=contours[0][i];
                temp1.y=temp1.x*k_1+b_1;
                temp2=temp1;
                temp2.y=temp2.x*k_2+b_2;
                residual1=distancepoint(temp1,contours[0][i]);
                residual2=distancepoint(temp2,contours[0][i]);
                if(residual2<3)
                    point2.push_back(contours[0][i]);
                if(residual1<3)
                    point1.push_back(contours[0][i]);

            }

            Vec4f fitted_point1, fitted_point2;
            fitLine(point1, fitted_point1, DIST_HUBER, 0, 0.01, 0.01);//直线拟合
            k_1 = fitted_point1[1] / fitted_point1[0];
            b_1 = fitted_point1[3] - k_1 * fitted_point1[2];
            fitLine(point2, fitted_point2, DIST_HUBER, 0, 0.01, 0.01);//直线拟合
            k_2 = fitted_point2[1] / fitted_point2[0];
            b_2 = fitted_point2[3] - k_2 * fitted_point2[2];

            x_1.x = cvRound(fitted_point1[2] - 500);
            x_1.y = cvRound(k_1 * x_1.x + b_1);
            x_2.x = cvRound(fitted_point1[2] + 500);
            x_2.y = cvRound(k_1 * x_2.x + b_1);

            x_3.x = cvRound(fitted_point2[2] - 1000);
            x_3.y = cvRound(k_2 * x_3.x + b_2);
            x_4.x = cvRound(fitted_point2[2] + 1000);
            x_4.y = cvRound(k_2 * x_4.x + b_2);

            kbp[r].emplace_back(Point2d(k_1,b_1),fitted_point1[2],fitted_point1[3]);
            kbp[r].emplace_back(Point2d(fitted_point1[2],fitted_point1[3]));
            kbp[r].push_back(mcenter);
            kbp[r].emplace_back(Point2d(k_2,b_2),fitted_point2[2],fitted_point2[3]);
            kbp[r].emplace_back(Point2d(fitted_point2[2],fitted_point2[3]));
            kbp[r].push_back(mcenter);

            if(k_1*k_2>0)
            {
                continue;
            }

            intersection1.resize(2);
            intersection2.resize(2);
            intersection1=compute_xy(image0,k_1,b_1);//计算直线与图像边缘的交点
            intersection2=compute_xy(image0,k_2,b_2);//计算直线与图像边缘的交点

            Point2d inter((b_2-b_1)/(k_1-k_2),((b_2-b_1)/(k_1-k_2)*k_1+b_1+(b_2-b_1)/(k_1-k_2)*k_2+b_2)/2);

            intersection_area.resize(4);
            int count(0);
            for(int i=0;i<intersection1.size();i++)
            {
                for(int j=0;j<intersection2.size();j++)
                {
                    intersection_area[count].push_back(intersection1[i]);
                    intersection_area[count].push_back(inter);
                    intersection_area[count].push_back(intersection2[j]);
                    count++;
                }
            }

            //计算周长
            int nt(0);
            float length_true=arcLength(contours[0],-1);//计算contours的周长
            for(int i=0;i<intersection_area.size();i++)
            {
                float a=distancepoint(intersection_area[i][0],intersection_area[i][1]);
                float b=distancepoint(intersection_area[i][0],intersection_area[i][2]);
                float c=distancepoint(intersection_area[i][1],intersection_area[i][2]);
                float p=(a+b+c);
                if(p/length_true>0.8&&p/length_true<1.2)
                {
                    intersection3.push_back(intersection1[i/2]);
                    intersection3.push_back(intersection2[i%2]);
                    nt++;
                }
            }
            if(nt>1)//计算距离
            {
                //intersection1.insert(intersection1.end(),intersection2.begin(),intersection2.end());//所有与图像边缘相交的点
                for(int i=0;i<intersection3.size();i++)
                {
                    intersection1.push_back(intersection3[i]);
                }
                intersection2.clear();
                vector<float> dist;
                float d;
                for(int i=0;i<intersection1.size();i+=2)
                {
                    dist.push_back((distancepoint(intersection1[i],Point2d(mcenter.x,mcenter.y))+distancepoint(intersection1[i+1],Point2d(mcenter.x,mcenter.y))));
                }
                int flag;
                float min=dist[0];
                for(int i=0;i<dist.size();i++)
                {
                    if(min>dist[i])
                    {
                        min=dist[i];
                        flag=i;
                    }
                }

                intersection2.push_back(intersection1[flag*2]);
                intersection2.push_back(intersection1[flag*2+1]);
                line(image, intersection2[0], inter, Scalar(255), 2,LINE_AA);
                line(image, intersection2[1], inter, Scalar(255), 2,LINE_AA);
            } else
            {
                line(image, intersection3[0], inter, Scalar(255), 2,LINE_AA);
                line(image, intersection3[1], inter, Scalar(255), 2,LINE_AA);
            }

            intersection1.clear();
            intersection2.clear();
            intersection3.clear();
            intersection_area.clear();
            point1.clear();
            point2.clear();
        }
        //比较每个contours的斜率。
        if(update_good_contour.size()==2)
        {
            if(center[0].y>center[1].y)
            {
                if(center[1].x>center[0].x)
                    //取k>0的边
                {
                    if(kb[0][0]>0)
                    {
                        k_b.emplace_back(kb[0][0],kb[0][1],xy[0][0],xy[0][1]);
                        if(kb[2][0]>0)
                            k_b.emplace_back(kb[2][0],kb[2][1],xy[2][0],xy[2][1]);
                        else if(kb[3][0]>0)
                        {
                            k_b.emplace_back(kb[3][0],kb[3][1],xy[3][0],xy[3][1]);
                        }

                    } else if(kb[1][0]>0)
                    {
                        if(kb[2][0]>0)
                            k_b.emplace_back(kb[2][0],kb[2][1],xy[2][0],xy[2][1]);
                        else if(kb[3][0]>0)
                        {
                            k_b.emplace_back(kb[3][0],kb[3][1],xy[3][0],xy[3][1]);
                        }
                    }
                } else
                {
                    if(kb[0][0]<0)
                    {
                        k_b.emplace_back(kb[0][0],kb[0][1],xy[0][0],xy[0][1]);
                        if(kb[2][0]<0)
                            k_b.emplace_back(kb[2][0],kb[2][1],xy[2][0],xy[2][1]);
                        else if(kb[3][0]<0)
                        {
                            k_b.emplace_back(kb[3][0],kb[3][1],xy[3][0],xy[3][1]);
                        }

                    } else if(kb[1][0]<0)
                    {
                        if(kb[2][0]<0)
                            k_b.emplace_back(kb[2][0],kb[2][1],xy[2][0],xy[2][1]);
                        else if(kb[3][0]<0)
                        {
                            k_b.emplace_back(kb[3][0],kb[3][1],xy[3][0],xy[3][1]);
                        }
                    }
                }
            }
            else
            {
                if(center[0].x>center[1].x)
                    //取k>0的边
                {
                    if(kb[0][0]>0)
                    {
                        k_b.emplace_back(kb[0][0],kb[0][1],xy[0][0],xy[0][1]);
                        if(kb[2][0]>0)
                            k_b.emplace_back(kb[2][0],kb[2][1],xy[0][0],xy[0][1]);
                        else if(kb[3][0]>0)
                        {
                            k_b.emplace_back(kb[3][0],kb[3][1],xy[0][0],xy[0][1]);
                        }

                    } else if(kb[1][0]>0)
                    {
                        k_b.emplace_back(kb[1][0],kb[1][1],xy[1][0],xy[1][1]);
                        if(kb[2][0]>0)
                            k_b.emplace_back(kb[2][0],kb[2][1],xy[2][0],xy[2][1]);
                        else if(kb[3][0]>0)
                        {
                            k_b.emplace_back(kb[3][0],kb[3][1],xy[3][0],xy[3][1]);
                        }
                    }
                } else
                {
                    if(kb[0][0]<0)
                    {
                        k_b.emplace_back(kb[0][0],kb[0][1],xy[0][0],xy[0][1]);
                        if(kb[2][0]<0)
                            k_b.emplace_back(kb[2][0],kb[2][1],xy[2][0],xy[2][1]);
                        else if(kb[3][0]<0)
                        {
                            k_b.emplace_back(kb[3][0],kb[3][1],xy[3][0],xy[3][1]);
                        }
                    } else if(kb[1][0]<0)
                    {
                        k_b.emplace_back(kb[1][0],kb[1][1],xy[1][0],xy[1][1]);
                        if(kb[2][0]<0)
                            k_b.emplace_back(kb[2][0],kb[2][1],xy[2][0],xy[2][1]);
                        else if(kb[3][0]<0)
                        {
                            k_b.emplace_back(kb[3][0],kb[3][1],xy[3][0],xy[3][1]);
                        }
                    }
                }
            }

        }






        imshow("feature", image);
        waitKey(0);

        good_contours.clear();


       update_good_contour.clear();
       good_contour_copy.clear();
       ij.clear();
       temp.clear();

    }
    return 0;
}
